package com;

import java.io.File;
import java.io.IOException;
import java.util.Scanner;

public class BusinessOperation {
	public static void CreateNewFile() throws IOException {
		   System.out.println("Enter the directory to add a file:");
		   String dir=new Scanner(System.in).nextLine();
		   System.out.println("Enter the filename to be added: ");
		   String filename=new Scanner(System.in).nextLine();
		   File newFile = new File(dir,filename);
	        //Create new file under specified directory
	        boolean isCreated = newFile.createNewFile();
	        if (isCreated) {
	            System.out.printf("\nSuccessfully created new file, path: "+newFile.getCanonicalPath());
	        } else { //File may already exist
	            System.out.printf("\nUnable to create new file!! File already exists");
	        }
	   }
	   public static void deleteFile() throws IOException {
		   System.out.println("Enter the directory in which the file has to be deleted");
		   String dirTodelete=new Scanner(System.in).nextLine();
		   System.out.println("Enter the filename to be deleted");
		   String filetoDelete=new Scanner(System.in).nextLine();
		   File file = new File(dirTodelete,filetoDelete);
        if(file.exists()) {
		     if (file.delete()) {
		         System.out.println("File deleted successfully:" +file.getName());
		     }
        }
		    else {
		         System.out.println("Failed to delete the file! File Not found in "+file.getCanonicalPath());
		     }
	}
		public static void searchFile() {
			System.out.println("Enter the root directory");
			String str=new Scanner(System.in).nextLine();
			System.out.println("Enter the file to be searched");
			String key=new Scanner(System.in).nextLine();
			File f=new File(str);
			String list[]=f.list();
			int n=list.length;
			int flag=0;
			if(n==0)
			{
				System.out.println("Directory is empty!!");
			}
			else
			{
				for(int i=0;i<n;i++)
				{
					String fname=list[i];
					if(fname.equals(key))
					{
						flag=1;
						break;
					}
				}
			}
			if(flag==0)
			{
				System.out.println("File not found!!");
			}
			else
			{
				System.out.println("The File "+key+" found!!");
			}
		}
}
