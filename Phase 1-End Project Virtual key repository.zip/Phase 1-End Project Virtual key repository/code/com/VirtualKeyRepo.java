package com;
import java.util.*;
import java.io.*;
public class VirtualKeyRepo {
	   public void SelectOptions() {
		  try {
		   
			  while(true)
				{
					System.out.println("\nFeatures of the Application:");
					System.out.println("1. Fetching Files in ascending order ");
					System.out.println("2. Business level Operations");
					System.out.println("3. Close Application");
	                System.out.println("**************************************");
 		            Scanner s=new Scanner(System.in);
 		            System.out.println("Please enter any of the above choices you want to perform:");
 		            int options=s.nextInt();
 		            switch(options) {
 		                       case 1://file fetching
 		                    	  
 			                          FetchFile.FetchingFile();
 			                          break;
 			                   
 		                       case 2://Business level operations
 		                    	      
 		                    	      BusinessOperation();
 		                    	      break;
 		                    	    
 		                       case 3://closing the application 
 		                    	      s.close();
 		                    	      CloseApp();
 		                    	      System.exit(1);
 		                    	      break;
 		                    	     
 		                       default: 
 		                    	      System.out.println("Oops!! Invalid input");
 		                    	      break;
 		            }
 		        }
		    }
		     catch(Exception e) {
			       e.printStackTrace();
		  }
    }
	   
          
	   
	   public void BusinessOperation() throws IOException {
		   while(true) {
				   System.out.println("\n**************************************");
			   	   System.out.println("Please choose any one of the following options");
			   	   System.out.println("1.Add a File");
			   	   System.out.println("2.Delete a File");
			   	   System.out.println("3.Search a File");
			   	   System.out.println("4.Navigate to main context\n");
			   	   System.out.println("**************************************");
	      	       System.out.println("\nEnter your choice");
	      	       int choice=new Scanner(System.in).nextInt();
	      	  
      	           switch(choice) {
      	                case 1://adding a file to a directory
      	                	   BusinessOperation.CreateNewFile();
      	                	   break;
      	                	   
      	                case 2://Deleting a file from a directory
      	                	   BusinessOperation.deleteFile();
      	                	   break;
      	                case 3://Searching a file in a directory
      	                	   BusinessOperation.searchFile();
      	                	   break;
      	                case 4://navigating to close current execution context
      	                	   //and return to main context
      	                	    System.out.println("********Navigating to main page********");
      	                	    SelectOptions();
      	                        break;
      	                default:
      	                	   System.out.println("oops!! Enter the Correct options given:");
      	                	   break;
      	           }
      	        
      	       }
	   }
	   
	   
       public void CloseApp() {
    	     System.out.println("\n**************************************\n");
    	     System.out.println("Thank You for using this Application");
    	     System.out.println("Meet you next time :)");
    	     System.out.println("\n**************************************\n");
       }
	   
       public static void main(String[] args) {
    	
    		    VirtualKeyRepo vk=new VirtualKeyRepo(); 
    		  
    		    System.out.println("\n**************************************\n");
    	        System.out.println("\tWelcome to LockedMe\n");
    	        System.out.println("**************************************");
    	        System.out.println("\tLockers Private Limited\n");
    	        System.out.println("**************************************");
    	        System.out.println("\tCode by Akshaya P :)\n");
    	        System.out.println("**************************************");
    	        vk.SelectOptions();
    		
    	  
    	}
}

