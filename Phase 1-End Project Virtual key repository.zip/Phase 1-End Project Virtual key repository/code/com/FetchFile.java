package com;

import java.io.File;
import java.util.ArrayList;
import java.util.Scanner;

public class FetchFile {
	public static void FetchingFile() {
        //Creating a File object for directory
		   System.out.println("Enter the root Directory:");
        String path=new Scanner(System.in).nextLine();
        File obj= new File(path);
        if(obj.isDirectory())
        {
      	  File ListOfFiles[] =obj.listFiles();

            System.out.println("List of files and directories in the specified directory : "+ListOfFiles.length);
            System.out.println("----------------------------------------------------------");
            if(ListOfFiles.length!=0) {
            // Creating a filter to return only files.
	            System.out.println("\n");
	
	            // Sort files by name
	            
	            int fileCount = 0;
	    	        ArrayList<String> filenames = new ArrayList<String>();
	    		   
	    		    fileCount = ListOfFiles.length;
	    		
	    		
	    		    System.out.println("\nFetching only Files in ascending order: ");
	    		    System.out.println("----------------------------------------------------------");
	
	    		    for (int i = 0; i < fileCount; i++) {
	    		    if (ListOfFiles[i].isFile()) {
	    		          filenames.add(ListOfFiles[i].getName());
	    		       } 
	    		    }
	    		
	    		    String[] str = new String[filenames.size()];
	    		 
	    	        for (int i = 0; i < filenames.size(); i++) {
	    	               str[i] = filenames.get(i);
	    	        }
	    		     
	    	        //Bubble sort to sort files in ascending order by ignoring a case
	    	        String temp = "";
	    	        int size=str.length;
	    	        for(int i=0; i<size; i++){
	    	        	for(int j=1; j<(size-i); j++){
	  				        if(str[j-1].compareToIgnoreCase(str[j])>0){
			     					temp = str[j-1];
			     					str[j-1]=str[j];
			     					str[j]=temp;
	  				        }
	  			     }
	  		    }
	    		
	  		   for (int i = 0; i < filenames.size(); i++) {
		                   System.out.println(filenames.get(i));
		           }
	    
	
	    	   }
            else     System.out.println("Empty Directory");
        }
      }
}
