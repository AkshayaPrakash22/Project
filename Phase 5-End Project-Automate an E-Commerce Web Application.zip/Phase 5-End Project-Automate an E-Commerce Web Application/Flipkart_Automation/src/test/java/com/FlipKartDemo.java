package com;
import java.util.NoSuchElementException;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
public class FlipKartDemo {
	WebDriver driver;
	String path1="C:\\\\Users\\\\admin\\\\Downloads\\\\chromedriver_win32\\\\chromedriver.exe";
	String path2="C:\\Users\\admin\\Downloads\\geckodriver-v0.31.0-win64\\geckodriver.exe";
	 @Test
	public void flipkart() throws Exception  {
		 
		 long start = System.currentTimeMillis();
		
		 driver.get("https://www.flipkart.com");
		 long finish = System.currentTimeMillis();
			 
		 //Page load time calculation
		 long totalTime = finish - start;
		 System.out.println("Page load time in ms is: "+totalTime+"\n");
		 String actual_title = driver.getTitle();
		 String expected_title = "Online Shopping Site for Mobiles, Electronics, Furniture, Grocery, Lifestyle, Books & More. Best Offers!";
		 Assert.assertEquals(actual_title, expected_title);
		 System.out.println("Page is navigated successfully!\n");
		 
		 //Closing the sign-in
		 driver.navigate().to("https://www.flipkart.com/search");
		
		 //identify image
		//Check image
		 WebElement imag = 
		driver.findElement(By.xpath("//*[@id=\"container\"]/div/div[1]/div[1]/div[2]/div[1]/div/a[1]/img"));
		 Boolean bool = (Boolean) 
		((JavascriptExecutor)driver).executeScript("return arguments[0].complete " + "&& typeof arguments[0].naturalWidth != \"undefined\" " + "&& arguments[0].naturalWidth > 0" , imag);
		 
		 if(bool)
		 {
			 System.out.println("Flipkart logo is present!");
		 }
		 else
		 {
			 System.out.println("Flipkart logo is not present!");
		 }

		driver.findElement(By.name("q")).sendKeys("iphone 13");
		driver.findElement(By.cssSelector("#container > div > div._1kfTjk > div._1rH5Jn > div._2Xfa2_ > div._1cmsER > form > div > button")).click();
		
		 Thread.sleep(3000);
		
		JavascriptExecutor js = (JavascriptExecutor)driver;
		js.executeScript("window.scrollBy(0,document.body.scrollHeight)");
		System.out.println("Reached At bottom of the page");
		
		Thread.sleep(3000);
		driver.navigate().refresh();
		
		Wait<WebDriver> wait = new FluentWait<WebDriver>(driver)							
				 .withTimeout(30, TimeUnit.SECONDS) 			
				.pollingEvery(5, TimeUnit.SECONDS) 			
				.ignoring(NoSuchElementException.class);
		WebElement clickseleniumlink = wait.until(new Function<WebDriver, WebElement>(){
		
			@Test
			public WebElement apply(WebDriver driver ) {
			//	return driver.findElement(By.cssSelector("#container > div > div._1kfTjk > div._1rH5Jn > div._2Xfa2_ > div._3_C9Hx > div > a:nth-child(1) > img"));
				
				WebElement element= driver.findElement(By.cssSelector("#container > div > div._1kfTjk > div._1rH5Jn > div._2Xfa2_ > div.go_DOp._2errNR > div > div > div > a"));
				String getTextOnPage= element.getText();
				
				if(getTextOnPage.equals("Login")) {
					System.out.println(getTextOnPage);
					System.out.println("Passed");
					return element;
				}
				else {
					System.out.println("Fluent Wait Fail!, Element Not Loaded Yet");
					return null;
				}
				
				
			}
		});
		}
		
		
	@Parameters("browser")
	@BeforeTest
	public void beforeMethod(String browser){
		if(browser.equalsIgnoreCase("chrome")) {
		     System.setProperty("webdriver.chrome.driver",path1);
		     System.out.println("Flipkart website opened using chrome\n");
		     driver= new ChromeDriver();
		     driver.manage().window().maximize();
		}else if(browser.equalsIgnoreCase("firefox")) {
			System.setProperty("webdriver.gecko.driver",path2);
			System.out.println("Flipkart website opened using firefox\n");
             driver= new FirefoxDriver();
		     driver.manage().window().maximize();
		}
		else {
			System.out.println("Invalid Browser");
		}
	
	}
	
	@AfterTest
	public void afterMethod() {
		
		driver=null;
	}
  
}
